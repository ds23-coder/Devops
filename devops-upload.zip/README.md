# DevOps Feedback App

Simple Flask app for DevOps CI/CD assessment.
